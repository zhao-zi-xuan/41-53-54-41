# README

* 第一题，见`p1.py`
* 第二题，见`mnist.py`
* 第三题，见`harris.py`