# README

运行`python main.py`就会输出报告里的全部图片

其中：
* `main.py`是主程序
* `solor_edit.py`是调色工具
* `utils.py`是计算各种分布图和曲线的工具