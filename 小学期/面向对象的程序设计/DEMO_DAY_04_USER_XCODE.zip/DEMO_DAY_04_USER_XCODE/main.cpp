//
//  main.cpp
//  DEMO_DAY_04_USER_XCODE
//
//  Created by Jingtao Fan on 2021/7/29.
//

#include <iostream>
#include "user.h"
#include "administrator.h"
#include "MD5.hpp"

int main(int argc, const char*  argv[]) {
//for first time, to create the user information file
//    Administrator* Admin = new Administrator();
//    Admin->AddUser("123", string("456"));
//    User::SaveToFile("/Users/jingtaofan/Desktop/2021OOP/DEMO/DEMO_DAY_04_USER/Users.txt");

//when you have a information file ,how to use
//    User::LoadFromFile("/Users/jingtaofan/Desktop/2021OOP/DEMO/DEMO_DAY_04_USER/Users.txt");
//    shared_ptr<User> Logined = User::Verify("Admin", string("Admin"));
//    cout << Logined->IsAdministrator() << endl;

    return 0;
}
