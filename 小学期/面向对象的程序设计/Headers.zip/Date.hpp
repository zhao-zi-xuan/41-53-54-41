//
//  Date.hpp
//  DEMO_DAY_04_USER_XCODE
//
//  Created by Jingtao Fan on 2021/8/5.
//

#ifndef Date_hpp
#define Date_hpp

#include <ctime>
#include <iostream>
using namespace std;

enum class WeekDayType {MON = 1, TUES = 2, WED = 3, THUR = 4, FRI = 5, SAT = 6 , SUN = 0};

class Date{
public:
    Date(unsigned int Year = 1900, unsigned int Month = 1, unsigned int Day = 1);
    Date(const Date& aDate);
    Date& operator=(const Date& aDate);
    ~Date();
    void Set(unsigned int Year, unsigned int Month, unsigned int Day);
    bool IsLeapYear() const;
    bool IsValid() const;
    //return the days'count from 0001-01-01, 0001-01-01 is the first(1, not 0) day
    unsigned int InDaysFromAD() const;
    bool operator> (const Date& aDate) const;
    bool operator< (const Date& aDate) const;
    bool operator>=(const Date& aDate) const;
    bool operator<=(const Date& aDate) const;
    bool operator==(const Date& aDate) const;
    bool operator!=(const Date& aDate) const;
    Date& operator++();
    Date  operator++(int);
    Date& operator--();
    Date  operator--(int);
    //return days'count between two date, today-yesterday is 1, yesterday-today is -1
    long long operator-(const Date& aDate) const;
    friend ostream& operator<<(ostream& Stream, const Date& aDate);
    friend istream& operator>>(istream& Stream, Date& aDate);
    static bool IsLeapYear(unsigned int Year);
    static bool IsValid(unsigned int Year, unsigned int Month, unsigned int Day);
    static Date Today();
    const unsigned int& Year;
    const unsigned int& Month;
    const unsigned int& Day;
    const WeekDayType& WeekDay;
private:
    unsigned int m_uYear;
    unsigned int m_uMonth;
    unsigned int m_uDay;
    WeekDayType m_WeekDay;
    static const unsigned int DaysInMonth[2][13];
    static const unsigned int GrigoreyYear;
};
#endif /* Date_hpp */
