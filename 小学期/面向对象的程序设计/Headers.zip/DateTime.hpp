//
//  DateTime.hpp
//  DEMO_DAY_04_USER_XCODE
//
//  Created by Jingtao Fan on 2021/8/5.
//

#ifndef DateTime_hpp
#define DateTime_hpp

#include "Date.hpp"
#include "Time.hpp"

class DateTime : public Date, public Time{
public:
    DateTime(const Date& aDate = Date(), const Time& aTime = Time());
    DateTime(unsigned int Year, unsigned int Month, unsigned int Day, unsigned int Hour, unsigned int Minute, unsigned int Second);
    bool operator  >(const DateTime& aDateTime) const;
    bool operator  <(const DateTime& aDateTime) const;
    bool operator >=(const DateTime& aDateTime) const;
    bool operator <=(const DateTime& aDateTime) const;
    bool operator ==(const DateTime& aDateTime) const;
    bool operator !=(const DateTime& aDateTime) const;
    DateTime& operator++();
    DateTime  operator++(int);
    DateTime& operator--();
    DateTime  operator--(int);
    DateTime Now();
    long long operator-(const DateTime& aDateTime) const;
    friend ostream& operator<<(ostream& Stream, const DateTime& aDateTime);
    friend istream& operator>>(istream& Stream, DateTime& aDateTime);
};

#endif /* DateTime_hpp */
