﻿/*************************************************************************
【文件名】                 AdminDialog.h
【功能模块和目的】          声明AdminDialog类
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#ifndef AdminDialog_H
#define AdminDialog_H

#include <QDialog>
#include<Admincontroler.h>
namespace Ui {
class AdminDialog;
}
/*************************************************************************
【类名】             AdminDialog
【功能】             Admin对话框
【接口说明】          AdminDialog(const shared_ptr<User>& userptr,QWidget *parent = nullptr)
                    ~AdminDialog()
                    on_ConfirmButton_clicked()
                    on_QuitButton_clicked()
【开发者及日期】      PengCheng 2021.8.7
*************************************************************************/
class AdminDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AdminDialog(const shared_ptr<User>& userptr,QWidget *parent = nullptr);//构造函数
    ~AdminDialog();//析构函数

private slots:
    void on_ConfirmButton_clicked();//confirm按钮槽函数，按下表示新建一个用户

    void on_QuitButton_clicked();//quit按钮槽函数，按下表示退出到登录界面


signals:
    void sendReshowsignal();//信号表示重新打开login界面

private:
    Ui::AdminDialog *ui;
    Admincontroler Controler;
};

#endif // AdminDialog_H
