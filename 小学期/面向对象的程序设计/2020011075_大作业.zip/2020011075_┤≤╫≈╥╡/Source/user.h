﻿/*************************************************************************
【文件名】                 user.h
【功能模块和目的】         用户类声明
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#ifndef USER_H
#define USER_H

#include<string>
#include<vector>
#include<iostream>
#include<memory>
using namespace std;

#include "CipherText.h"

/*************************************************************************
【类名】             User
【功能】             存储用户
【接口说明】         virtual bool IsAdministrator() const
                   void OutputToStream(ostream& Stream) const
                   static void SaveToFile(const string& FileName)
                   static void LoadFromFile(const string& FileName)
                   static shared_ptr<User> Verify(const string& Name, const string& Password)
【开发者及日期】     PengCheng 2021.8.7
*************************************************************************/
class User
{
public:
    User() = delete;
    User(const User&) = delete;
    User& operator=(const User&) = delete;

    virtual bool IsAdministrator() const;//返回是否为管理员
    void OutputToStream(ostream& Stream) const;//输出到流
    static void SaveToFile(const string& FileName);//保存到文件
    static void LoadFromFile(const string& FileName);//从文件读取
    static shared_ptr<User> Verify(const string& Name, const string& Password);//返回用户指针
protected:
    User(const string& Name, const CipherText& Password);//构造函数，保护，表示只能通过子类管理员添加
    void AddUser(const string& Name, const CipherText& Password);//添加用户
private:
    static vector<shared_ptr<User>> m_All;//含有所有用户信息的容器
    string m_Name;//用户名
    CipherText m_Password;//密码
};

#endif // USER_H
