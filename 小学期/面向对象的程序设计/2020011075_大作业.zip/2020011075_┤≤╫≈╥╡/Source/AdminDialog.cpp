﻿/*************************************************************************
【文件名】                 AdminDialog.cpp
【功能模块和目的】         AdminDialog类函数定义
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/

#include "AdminDialog.h"
#include "ui_AdminDialog.h"
#include <QMessageBox>

/*************************************************************************
【函数名称】       AdminDialog
【函数功能】       构造函数
【参数】           const shared_ptr<User>& userptr,QWidget *parent
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
AdminDialog::AdminDialog(const shared_ptr<User>& userptr,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AdminDialog)
{
    ui->setupUi(this);
    Controler.Setuserptr(userptr);
}

/*************************************************************************
【函数名称】       ~AdminDialog()
【函数功能】       析构函数
【参数】           \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
AdminDialog::~AdminDialog()
{
    delete ui;
}

/*************************************************************************
【函数名称】         on_ConfirmButton_clicked()
【函数功能】         confirm按钮槽函数，创建新用户
【参数】             \
【返回值】           \
【开发者及日期】      pengcheng 2021.8.7
*************************************************************************/
void AdminDialog::on_ConfirmButton_clicked()
{
    QString newname = ui->NewNameEdit->text();
    QString newpassword = ui->NewPasswordEdit->text();
    QString checkpassword = ui->CheckPasswordEdit->text();
    if(newpassword!=checkpassword){
        QMessageBox::information(NULL, "创建失败", "密码错误", QMessageBox::Ok);
    }
    else{
        AdminResult Res=Controler.AddNewUser(newname,newpassword);
        if (Res == AdminResult::NULL_PASSWARD) {
            QMessageBox::information(NULL, "创建失败", "密码为空", QMessageBox::Ok);
        }
        else if (Res == AdminResult::USERNAME_ALREADY_EXIST) {
            QMessageBox::information(NULL, "创建失败", "用户名已存在", QMessageBox::Ok);
        }
        else if (Res == AdminResult::NEWUSER_BUILT) {
            QMessageBox::information(NULL, "创建成功", "新用户已创建", QMessageBox::Ok);

        }
        else if (Res == AdminResult::ADMIN_ALREADY_EXIST) {
            QMessageBox::information(NULL, "创建失败", "不可创建管理员", QMessageBox::Ok);

        }
    }

}
/*************************************************************************
【函数名称】         on_QuitButton_clicked()
【函数功能】         QuitButton按钮槽函数，返回登录界面并销毁窗口
【参数】             \
【返回值】           \
【开发者及日期】      pengcheng 2021.8.7
*************************************************************************/
void AdminDialog::on_QuitButton_clicked()
{
    emit sendReshowsignal();
    this->close();
    this->setAttribute(Qt::WA_DeleteOnClose,  true);
}


