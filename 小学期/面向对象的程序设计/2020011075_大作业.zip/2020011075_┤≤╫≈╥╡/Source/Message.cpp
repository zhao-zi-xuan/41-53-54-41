﻿/*************************************************************************
【文件名】                message.h
【功能模块和目的】         message类定义
【开发者及日期】           PengCheng 2021.7.31
*************************************************************************/
#include"Message.h"
#include <vector>
#include <stdexcept>
#include <algorithm>
#include <memory>
#include<fstream>
using namespace std;

vector<shared_ptr<Message>> Message::m_AllMessage{};

/*************************************************************************
【函数名称】       Message
【函数功能】       构造函数
【参数】          Datetime dt,Type tp, string content
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
Message::Message(Datetime dt,Type tp, string content):datetime(m_Datetime),content(m_content),type(m_type){
    if(content == ""){
        throw invalid_argument("Isn't ValidContent");
    }
    m_Datetime = dt;
    m_content = content;
    m_type = tp;
    m_AllMessage.push_back(shared_ptr<Message>(this));
}

/*************************************************************************
【函数名称】       SearchMessage
【函数功能】       查找信息
【参数】          const Datetime& begin,const Datetime& end
【返回值】         vector<shared_ptr<Message>>*
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
vector<shared_ptr<Message>>* Message::SearchMessage(const Datetime& begin,const Datetime& end){
    Datetime newend = end;
    if(newend<begin){
        throw invalid_argument("WrongRange");
    }
    Message::SortMessage();
    vector<shared_ptr<Message>>* prtMessage = new vector<shared_ptr<Message>>;
    auto Saver = [&](shared_ptr<Message> M){
        if( (M->m_Datetime > begin || M->m_Datetime == begin) && (M->m_Datetime < end || M->m_Datetime == end)) prtMessage->push_back(M);
    };
    for_each(Message::m_AllMessage.begin(), Message::m_AllMessage.end(), Saver);
    if(prtMessage->empty()){
        throw invalid_argument("NullMesssage");
    }
    return prtMessage;
}

/*************************************************************************
【函数名称】      PublishMessage
【函数功能】       发布信息
【参数】          const Datetime& dt,const Type& tp, const string& content
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void Message::PublishMessage(const Datetime& dt,const Type& tp, const string& content){
    new Message(dt, tp, content);
}

/*************************************************************************
【函数名称】       SortMessage
【函数功能】       按时间排序
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void Message::SortMessage() {
    auto fun = [&](shared_ptr<Message> M1, shared_ptr<Message> M2) {return (M1->m_Datetime < M2->m_Datetime); };
    sort(m_AllMessage.begin(), m_AllMessage.end(), fun);
}

/*************************************************************************
【函数名称】       OutputToStream
【函数功能】       输出到流
【参数】          ostream& Stream
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void Message::OutputToStream(ostream& Stream) const {
    Stream << m_Datetime << ToString(m_type) << endl << m_content << endl<<string("###End###")<<endl;
}

/*************************************************************************
【函数名称】       LoadFromFile
【函数功能】       从文件读取
【参数】          const string& FileName
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void Message::LoadFromFile(const string& FileName) {

    ifstream File(FileName);
    if (!File.is_open()) {
        throw invalid_argument("File Not Exist: " + FileName);
    }
    m_AllMessage.clear();
    unsigned long MessageCount;
    Date adate;
    Time atime;
    string tp;
    string content,temp;
    File >> MessageCount;
    File.get();
    for (unsigned long i = 0; i < MessageCount; i++) {
        File >> adate >> atime;
        File >> tp;
        File.get();
        File >> temp;
        content="";
        while(temp!="###End###")
        {
            content+=temp;
            File >> temp;
            if(temp=="###End###") break;
            content+="\n";

        }
        Datetime mdt(adate, atime);
        new Message(mdt, FromString(tp),content);
    }
    File.close();
}

/*************************************************************************
【函数名称】       SaveToFile
【函数功能】       保存到文件
【参数】          const string& FileName
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void Message::SaveToFile(const string& FileName) {
    ofstream File(FileName);
    if (!File.is_open()) {
        throw invalid_argument("Can't Create File : " + FileName);
    }
    auto Saver = [&File](shared_ptr<Message> Ptr) {Ptr->OutputToStream(File); };
    File << m_AllMessage.size() << endl;
    for_each(m_AllMessage.begin(), m_AllMessage.end(), Saver);
    File.close();
}

/*************************************************************************
【函数名称】       FromString
【函数功能】       将string转为Type类型
【参数】          const string& str
【返回值】         Type
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
Type Message::FromString(const string& str) {
    if (str == "Word") {
        return Type::WORD;
    }
    else if (str == "Action") {
        return Type::ACTION;
    }
    else if (str == "Thought") {
        return Type::THOUGHT;
    }
    else {
        throw invalid_argument("Invalid Message Type");
    }
}

/*************************************************************************
【函数名称】       ToString
【函数功能】       Type类型转为string
【参数】          const Type& tp
【返回值】         string
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
string Message::ToString(const Type& tp) {
    if (tp == Type::WORD) {
        return "Word";
    }
    else if (tp == Type::ACTION) {
        return "Action";
    }
    else if (tp == Type::THOUGHT) {
        return "Thought";
    }
    else{
        return "Word";
    }
}

/*************************************************************************
【函数名称】       operator<<
【函数功能】       输出运算符重载
【参数】          ostream& output, const Message& mg
【返回值】         ostream&
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
ostream& operator<<(ostream& output, const Message& mg){
    output << mg.m_Datetime << Message::ToString(mg.m_type) << endl << mg.m_content << endl;
    return output;
}
istream& operator>>(istream& input, Message& mg) {
    string tp;
    input >> mg.m_Datetime >> tp >> mg.m_content;
    mg.m_type = Message::FromString(tp);
    return input;
}
