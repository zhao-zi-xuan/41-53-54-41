﻿/*************************************************************************
【文件名】                 administrator.h
【功能模块和目的】         声明Administrator类
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H

#include "user.h"
#include "CipherText.h"
#include <string>
using namespace std;


/*************************************************************************
【类名】             Administrator
【功能】             管理员类，用于创建用户
【接口说明】         void AddUser(const string& Name, const string& Password)
                   Administrator()
                   Administrator(const CipherText& Password)
                   bool IsAdministrator() const override
【开发者及日期】     PengCheng 2021.8.7
*************************************************************************/
class Administrator : public User
{
public:
    Administrator(const Administrator&) = delete ;//删除拷贝构造
    Administrator& operator=(const Administrator&) = delete;//赋值运算符重载
    void AddUser(const string& Name, const string& Password);//添加用户
    Administrator();//默认构造
    Administrator(const CipherText& Password);//带参构造，设置管理员密码
    bool IsAdministrator() const override;//判断是否为管理员
};

#endif // ADMINISTRATOR_H
