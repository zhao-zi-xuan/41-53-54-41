﻿/*************************************************************************
【文件名】                 Admincontroler.h
【功能模块和目的】          声明类Admincontroler
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#ifndef Admincontroler_H
#define Admincontroler_H

#include"administrator.h"
#include<QString>
enum class AdminResult
{
    NEWUSER_BUILT,
    USERNAME_ALREADY_EXIST,
    NULL_PASSWARD,
    ADMIN_ALREADY_EXIST
};

/*************************************************************************
【类名】            Admincontroler
【功能】            作为控制器控制底层类Administrator和界面类AdminDialog
【接口说明】        Admincontroler()
                  AdminResult AddNewUser(const QString& Name, const QString& Password)
                  void Setuserptr(const shared_ptr<User>& userptr)
【开发者及日期】     PengCheng 2021.8.7
*************************************************************************/
class Admincontroler
{
public:
    Admincontroler();//构造函数
    AdminResult AddNewUser(const QString& Name, const QString& Password);//添加新用户，返回添加结果
    void Setuserptr(const shared_ptr<User>& userptr);//存从login窗口传来的用户指针
    ~Admincontroler();
private:
    shared_ptr<User> m_userptr;//从login窗口传来的用户指针
};

#endif // Admincontroler_H
