﻿/*************************************************************************
【文件名】                 Time.cpp
【功能模块和目的】         Time类定义
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#include "Time.hpp"
#include <iostream>
#include<iomanip>


/*************************************************************************
【函数名称】       Set
【函数功能】       设置私有成员时分秒变量
【参数】          unsigned int Hour, unsigned int Minute, unsigned int Second
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void Time::Set(unsigned int Hour, unsigned int Minute, unsigned int Second){
    if (Hour < 24 && Minute < 60 && Second < 60) {
        this->m_Hour = Hour;
        this->m_Minute = Minute;
        this->m_Second = Second;
    }
    else{
        throw invalid_argument("Isn't ValidTime");
    }
}

/*************************************************************************
【函数名称】       Time
【函数功能】       构造函数
【参数】          unsigned int Hour, unsigned int Minute, unsigned int Second
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
Time::Time(unsigned int Hour, unsigned int Minute, unsigned int Second): Hour(m_Hour), Minute(m_Minute), Second(m_Second){
    Set(Hour, Minute, Second);
}

/*************************************************************************
【函数名称】       operator<<
【函数功能】       输出运算符重载
【参数】          ostream& output, const Time& t
【返回值】         ostream&
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
ostream& operator<<(ostream& output, const Time& t){
    output<< setfill('0') << setw(2) << t.Hour << ":"
          << setfill('0') << setw(2) << t.Minute <<":"
          << setfill('0') << setw(2) << t.Second ;
    return output;

}

/*************************************************************************
【函数名称】       operator>>
【函数功能】       输入运算符重载
【参数】          istream& input, Time& t
【返回值】         istream&
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
istream& operator>>(istream& input, Time& t){
    input >> t.m_Hour;
    input.get();
    input>> t.m_Minute;
    input.get();
    input>> t.m_Second;
    input.get();
    return input;

}

/*************************************************************************
【函数名称】       Time::operator<
【函数功能】       比较运算符重载
【参数】          输入(const Time& t)
【返回值】         bool类型
【开发者及日期】   PengCheng 2021.8.1
【更改记录】       \
*************************************************************************/
bool Time::operator<(const Time& t)
     {
        if(Hour < t.Hour)
        {
           return true;
        }
        else if(Hour == t.Hour && Minute < t.Minute)
        {
           return true;
        }
        else if(Hour == t.Hour && Minute == t.Minute && Second < t.Second)
        {
           return true;
        }
        else return false;
     }

/*************************************************************************
【函数名称】       Time::operator>
【函数功能】       比较运算符重载
【参数】          输入(const Time& t)
【返回值】         bool类型
【开发者及日期】   PengCheng 2021.8.1
【更改记录】       \
*************************************************************************/
bool Time::operator>(const Time& t)
     {
    if(Hour > t.Hour)
    {
       return true;
    }
    else if(Hour == t.Hour && Minute > t.Minute)
    {
       return true;
    }
    else if(Hour == t.Hour && Minute == t.Minute && Second > t.Second)
    {
       return true;
    }
    else return false;
     }
/*************************************************************************
【函数名称】       Time::operator==
【函数功能】       比较运算符重载
【参数】          输入(const Time& t)
【返回值】         bool类型
【开发者及日期】   PengCheng 2021.8.1
【更改记录】       \
*************************************************************************/
bool Time::operator==(const Time& t)
     {

        if(Hour == t.Hour && Minute == t.Minute && Second == t.Second)
        {
           return true;
        }
        else return false;
     }
/*************************************************************************
【函数名称】       Time::operator=
【函数功能】       赋值运算符重载
【参数】          输入(const Time& aTime)
【返回值】         Time&类型
【开发者及日期】   PengCheng 2021.8.1
【更改记录】       \
*************************************************************************/
Time& Time::operator=(const Time& aTime) {
    if (this != &aTime) {
        m_Hour = aTime.Hour;
        m_Minute = aTime.Minute;
        m_Second = aTime.Second;
    }
    return *this;
}
