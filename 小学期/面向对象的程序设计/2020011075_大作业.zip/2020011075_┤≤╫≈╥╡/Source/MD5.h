﻿/*************************************************************************
【文件名】                 MD5.h
【功能模块和目的】         MD5类声明
【开发者及日期】           Created by Jingtao Fan on 2021/7/29.
*************************************************************************/
//改写以下链接，版权声明如下
//版权声明：本文为CSDN博主「haroroda」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
//原文链接：https://blog.csdn.net/haroroda/article/details/45935099
#ifndef MD5_h
#define MD5_h

#include <string>
using namespace std;
class MD5 {
public:
    MD5(const string& PlainText);//构造函数
    MD5() = delete;
    virtual ~MD5();//析构函数
    static string Encrypt(const string& Plaintext);//静态加密函数
protected:
    string Process(const string& PlainText) const;//加密明文
    string m_CipherText;
private:
    string c_out(int* a) const;// 密文输出函数
    void DecToBin(int in, int n, int* md5) const;//十进制转二进制函数
    void DecToBin_Coefficient(int in, int* md5) const;// 位数填充时所用到的十进制转二进制函数 */
    void HexToBin(char* t, int* temp) const;//十六进制转二进制函数
    void F(int* b, int* c, int* d, int* temp1, int* temp2) const;// F函数
    void G(int* b, int* c, int* d, int* temp1, int* temp2) const;// G函数
    void H(int* b, int* c, int* d, int* temp) const;// H函数
    void I(int* b, int* c, int* d, int* temp) const;// I函数
    void AND(int* a, int* b, int* temp) const;// 与函数
    void OR(int* a, int* b, int* temp) const;// 或函数
    void NOT(int* a, int* temp) const;// 非函数
    void XOR(int* a, int* b, int* temp) const;//异或函数
    void ADD(int* a, int* b, int* temp) const;// 模二的32次加
    void move(int step, int* temp1, int* temp2) const;//左移函数
    void round(int* a, int* b, int* c, int* d, int* m, int* md5, int r, char t[16][8]) const;//每一大轮的16小轮循环函数
    
    static const char T_INIT_VALUE[64][8];
    static const int  M_INIT_VALUE[4][16];
    static const int  A_INIT_VALUE[2][32];
    static const int  B_INIT_VALUE[2][32];
    static const int  C_INIT_VALUE[2][32];
    static const int  D_INIT_VALUE[2][32];
};
#endif /* MD5_h */
