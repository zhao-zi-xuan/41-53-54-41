﻿/*************************************************************************
【文件名】                administrator.cpp
【功能模块和目的】         Administrator类函数定义
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#include "administrator.h"

/*************************************************************************
【函数名称】       AddUser
【函数功能】       添加新用户
【参数】          const string &Name, const string& Password
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void Administrator::AddUser(const string &Name, const string& Password){
    if(Password == ""){
        throw invalid_argument("No Password");
    }
    CipherText CipherPassword(Password);
    this->User::AddUser(Name, CipherPassword);
}
/*************************************************************************
【函数名称】       IsAdministrator
【函数功能】       判断是否为管理员
【参数】          \
【返回值】         bool型，true
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
bool Administrator::IsAdministrator() const {
    return true;
}

/*************************************************************************
【函数名称】       Administrator
【函数功能】       构造函数，构造用户名密码均为"Admin"的管理员对象
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
Administrator::Administrator():User("Admin", string("Admin")) {

}

/*************************************************************************
【函数名称】       Administrator
【函数功能】       构造指定密码管理员对象
【参数】          const CipherText& Password
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
Administrator::Administrator(const CipherText& Password):User("Admin", Password) {
    
}
