﻿/*************************************************************************
【文件名】               Datetime.h
【功能模块和目的】         Datetime类声明
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#ifndef Datetime_h
#define Datatime_h
#include "Date.hpp"
#include"Time.hpp"
using namespace std;

/*************************************************************************
【类名】             Datetime
【功能】             时间日期类，存储时间日期
【接口说明】         Datetime(Date& aDate = d_Date, Time& aTime = d_Time)
                   friend ostream& operator<<(ostream& output, const Datetime& dt)
                   friend istream& operator>>(istream& input, Datetime& dt)
                   bool operator < (const Datetime& dt)
                   bool operator > (const Datetime& dt)
                   bool operator == (const Datetime& dt)
                   Datetime& operator=(const Datetime& dt)
                   static string Tostring(const Datetime& dt)
                   const Date& date
                   const Time& time
【开发者及日期】     PengCheng 2021.8.7
*************************************************************************/
class Datetime {
public:
    Datetime(Date& aDate = d_Date, Time& aTime = d_Time);//构造函数
    friend ostream& operator<<(ostream& output, const Datetime& dt);//输出符重载
    friend istream& operator>>(istream& input, Datetime& dt);//输入符重载
    bool operator < (const Datetime& dt);//小于号重载
    bool operator > (const Datetime& dt);//大于号重载
    bool operator == (const Datetime& dt);//相等判断符重载
    Datetime& operator=(const Datetime& dt);//赋值运算符重载
    static string Tostring(const Datetime& dt);//转换为标准输出string类型
    const Date& date;
    const Time& time;
private:
    static Date d_Date;//默认日期
    static Time d_Time;//默认时间
    Date mDate;
    Time mTime;

};





#endif
