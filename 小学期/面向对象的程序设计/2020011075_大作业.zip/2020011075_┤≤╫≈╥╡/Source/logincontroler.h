﻿/*************************************************************************
【文件名】                 logincontroler.h
【功能模块和目的】          声明类LoginControler
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#ifndef LOGINCONTROLER_H
#define LOGINCONTROLER_H

#include <QString>
#include "user.h"

//枚举类返回结果
enum class LoginResult
{
    ADMIN_LOGINED,
    USER_LOGINED,
    NO_USER,
    WRONG_PASSWORD,
};

/*************************************************************************
【类名】            LoginControler
【功能】            作为控制器控制底层类和界面类logindialog
【接口说明】         LoginControler()
                   LoginResult Login(const QString& Name, const QString& Password);
                   const shared_ptr<User>& userptr;
【开发者及日期】     PengCheng 2021.8.7
*************************************************************************/
class LoginControler
{
public:
    LoginControler();//构造函数，读取用户信息文件
    LoginResult Login(const QString& Name, const QString& Password);//登录函数，接受用户名密码，返回登录结果
    const shared_ptr<User>& userptr;
private:
    shared_ptr<User> m_userptr;
};

#endif // LOGINCONTROLER_H
