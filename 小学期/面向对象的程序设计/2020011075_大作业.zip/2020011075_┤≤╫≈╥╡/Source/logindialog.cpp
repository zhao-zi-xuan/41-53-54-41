﻿/*************************************************************************
【文件名】                 （必需）
【功能模块和目的】         （必需）
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#include <QMessageBox>
#include "logindialog.h"
#include "ui_logindialog.h"
#include "AdminDialog.h"
#include "MessageWindow.h"



/*************************************************************************
【函数名称】       LoginDialog
【函数功能】       构造函数
【参数】          QWidget *parent
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
LoginDialog::LoginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDialog)
{
    ui->setupUi(this);
}

/*************************************************************************
【函数名称】       ~LoginDialog
【函数功能】       析构函数
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
LoginDialog::~LoginDialog()
{
    delete ui;
}

/*************************************************************************
【函数名称】       on_loginBotton_clicked
【函数功能】       登录按钮槽函数
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void LoginDialog::on_loginBotton_clicked()
{
    LoginResult Res = Controler.Login(ui->usrlineEdit->text(),ui->pwdlineEdit->text());
    if (Res == LoginResult::NO_USER) {
        QMessageBox::information(NULL, "登录失败", "用户名不存在！", QMessageBox::Ok);
    }
    else if (Res == LoginResult::WRONG_PASSWORD) {
        QMessageBox::information(NULL, "登录失败", "密码错误！", QMessageBox::Ok);
    }
    else if (Res == LoginResult::ADMIN_LOGINED) {
        QMessageBox::information(NULL, "登录成功", "管理员已登录！", QMessageBox::Ok);
        this->hide();
        AdminDialog* Adminwindow = new AdminDialog(Controler.userptr,nullptr);
        connect(Adminwindow,SIGNAL(sendReshowsignal()),this,SLOT(reshow()));
        Adminwindow->show();
    }
    else {
        QMessageBox::information(NULL, "登录成功", "用户 " + ui->usrlineEdit->text() + " 已登录！", QMessageBox::Ok);
        MessageWindow* messagewindow = new MessageWindow(nullptr);
        this->hide();
        connect(messagewindow,SIGNAL(Reshowsignal()),this,SLOT(reshow()));
        messagewindow->show();
    }

}

/*************************************************************************
【函数名称】       reshow
【函数功能】       重新显示登录界面
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void LoginDialog::reshow(){
    this->show();
}

/*************************************************************************
【函数名称】       on_exitButton_clicked()
【函数功能】       退出登录界面
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void LoginDialog::on_exitButton_clicked()
{
    this->close();
}
