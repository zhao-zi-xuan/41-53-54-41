﻿/*************************************************************************
【文件名】                Time.hpp
【功能模块和目的】         Time类声明
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#ifndef Time_hpp
#define Time_hpp
#include<iostream>
#include <string>
using namespace std;

/*************************************************************************
【类名】             Time
【功能】             设置存储时间
【接口说明】         Time(unsigned int Hour = 0, unsigned int Minute = 0, unsigned int Second = 0)
                   void Set(unsigned int Hour, unsigned int Minute, unsigned int Second)
                   const unsigned int& Hour
                   const unsigned int& Minute
                   const unsigned int& Second
                   friend ostream& operator<<(ostream& output, const Time& t)
                   friend istream &operator>>( istream  &input, Time &t )
                   bool operator <(const Time& t)
                   bool operator>(const Time& t)
                   bool operator==(const Time& t)
                   Time& operator=(const Time& aTime)
【开发者及日期】     PengCheng 2021.8.7
*************************************************************************/
class Time {
public:

    Time(unsigned int Hour = 0, unsigned int Minute = 0, unsigned int Second = 0);//构造
    void Set(unsigned int Hour, unsigned int Minute, unsigned int Second);//设置时分秒
    const unsigned int& Hour;
    const unsigned int& Minute;
    const unsigned int& Second;
    friend ostream& operator<<(ostream& output, const Time& t);//输出运算符重载
    friend istream& operator>>(istream& input, Time& t);//输入运算符重载
    bool operator<(const Time& t);//小于号重载
    bool operator>(const Time& t);//大于号重载
    bool operator==(const Time& t);//比较判断重载
    Time& operator=(const Time& aTime);//赋值运算符重载

protected:
    unsigned int m_Hour;
    unsigned int m_Minute;
    unsigned int m_Second;
};

#endif /* Time_hpp */
