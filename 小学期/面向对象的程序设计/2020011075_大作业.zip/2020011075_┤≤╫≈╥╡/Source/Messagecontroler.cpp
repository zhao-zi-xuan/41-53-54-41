﻿/*************************************************************************
【文件名】                Messagecontroler.cpp
【功能模块和目的】         Messagecontroler类定义
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#include "Messagecontroler.h"
#include "Message.h"


/*************************************************************************
【函数名称】       Messagecontroler
【函数功能】       构造，从文件读取message
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
Messagecontroler::Messagecontroler():prtMessage(m_prtMessage),word(m_word),action(m_action),thought(m_thought)
{
    Message::LoadFromFile("Messages.txt");


}

/*************************************************************************
【函数名称】       ~Messagecontroler
【函数功能】       析构，存储message到文件
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
Messagecontroler::~Messagecontroler(){
    Message::SaveToFile("Messages.txt");
}

/*************************************************************************
【函数名称】       Messagesearch
【函数功能】       查找message并返回查找结果
【参数】          const QDateTime& begin, const QDateTime& end
【返回值】         SearchResult
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
SearchResult Messagecontroler::Messagesearch(const QDateTime& begin, const QDateTime& end){
    m_prtMessage.clear();
    m_word = 0;
    m_action = 0;
    m_thought = 0;
    try {
        Datetime begindt = FromQDateTime(begin);
        Datetime enddt = FromQDateTime(end);
        vector<shared_ptr<Message>>* ptr=Message::SearchMessage(begindt,enddt);
        m_prtMessage=*ptr;
        delete ptr;
        auto print = [&](shared_ptr<Message> M) {cout << M->datetime << endl; };
        for_each(m_prtMessage.begin(), m_prtMessage.end(), print);
        auto count = [&](shared_ptr<Message> M){
            if(M->type==Type::WORD){m_word++;}
            else if(M->type==Type::ACTION){m_action++;}
            else if(M->type==Type::THOUGHT){m_thought++;}
        };
        for_each(prtMessage.begin(),prtMessage.end(),count);
    } catch (invalid_argument e) {
        if (e.what() == string("NullMessage")) {
            return SearchResult::NULLMessage;
    }
        else if (e.what() == string("WrongRange")||e.what()==string("Isn't ValidDate")) {
            return SearchResult::InvalidDateTimeRange;
    }
        else return SearchResult::Success;
    }
}

/*************************************************************************
【函数名称】       MessagePublish
【函数功能】       发布信息返回发布结果
【参数】          QDateTime& dt,QString& tp, QString& content
【返回值】         PublishResult
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
PublishResult Messagecontroler::MessagePublish(QDateTime& dt,QString& tp, QString& content){
    try{
        Datetime datetime = FromQDateTime(dt);
        Message::PublishMessage(datetime, Message::FromString(tp.toStdString()), content.toStdString());
        Message::SaveToFile("Messages.txt");
        return PublishResult::Success;
    }catch (invalid_argument e) {
        if (e.what() == string("Isn't ValidDate")) {
            return PublishResult::WrongDate;
        }
        else if (e.what() == string("Isn't ValidTime")) {
            return PublishResult::WrongTime;
        }
        else if (e.what() == string("Isn't ValidType")) {
            return PublishResult::WrongType;
        }
        else if (e.what() == string("Isn't ValidContent")) {
            return PublishResult::WrongContent;
        }
        else{
            return PublishResult::Success;
        }
    }
}

/*************************************************************************
【函数名称】       FromQDateTime
【函数功能】       从QDatetime转为Datetime
【参数】          const QDateTime& qdatetime
【返回值】         Datetime
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
Datetime Messagecontroler::FromQDateTime(const QDateTime& qdatetime){
    QDate qdate = qdatetime.date();
    QTime qtime = qdatetime.time();
    Date date(qdate.year(),qdate.month(),qdate.day());
    Time time(qtime.hour(),qtime.minute(),qtime.second());
    Datetime datetime(date,time);
    return datetime;
}
