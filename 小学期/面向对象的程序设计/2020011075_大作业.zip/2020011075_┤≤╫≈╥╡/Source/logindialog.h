﻿/*************************************************************************
【文件名】                logindialog.h
【功能模块和目的】         LoginDialog类声明
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H
#include "logincontroler.h"
#include "MessageWindow.h"
#include <QDialog>

namespace Ui {
class LoginDialog;
}

/*************************************************************************
【类名】             LoginDialog
【功能】             LoginDialog界面类
【接口说明】         explicit LoginDialog(QWidget *parent = nullptr);
                   ~LoginDialog();
                   void reshow();
【开发者及日期】     PengCheng 2021.8.7
*************************************************************************/
class LoginDialog : public QDialog
{
    Q_OBJECT

public:
    explicit LoginDialog(QWidget *parent = nullptr);//构造函数
    ~LoginDialog();//析构函数

public slots:
    void reshow();//重新显示此界面

private slots:
    void on_loginBotton_clicked();//login槽函数
    void on_exitButton_clicked();//exit槽函数

private:
    Ui::LoginDialog *ui;
    LoginControler Controler;

};

#endif // LOGINDIALOG_H
