﻿/*************************************************************************
【文件名】                 CipherText.cpp
【功能模块和目的】         加密字符串类函数定义
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#include <string>
using namespace std;
#include "CipherText.h"

/*************************************************************************
【函数名称】       CipherText
【函数功能】       构造函数
【参数】          const string& Plainext
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
CipherText::CipherText(const string& Plainext) : MD5(Plainext){
 
}

/*************************************************************************
【函数名称】       operator==
【函数功能】       比较运算符重载
【参数】          const string& Plaintext
【返回值】         bool
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
bool CipherText::operator==(const string& Plaintext) {
    return m_CipherText == MD5::Encrypt(Plaintext);
}

/*************************************************************************
【函数名称】       operator!=
【函数功能】       不等号重载
【参数】          const string& Plaintext
【返回值】         bool
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
bool CipherText::operator!=(const string& Plaintext) {
    return !operator==(Plaintext);
}

/*************************************************************************
【函数名称】       operator<<
【函数功能】       输出运算符重载
【参数】          ostream& stream, const CipherText& CipherText
【返回值】         ostream&
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
ostream& operator<<(ostream& stream, const CipherText& CipherText){
    stream << CipherText.m_CipherText;
    return stream;
}

/*************************************************************************
【函数名称】       MakeFromCipherText
【函数功能】       将string型密文转为Ciphertext型密文
【参数】          const string& CipherText
【返回值】         CipherText
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
CipherText CipherText::MakeFromCipherText(const string& CipherText){
    class CipherText P1("123");
    P1.m_CipherText = CipherText;
    return P1;
}
