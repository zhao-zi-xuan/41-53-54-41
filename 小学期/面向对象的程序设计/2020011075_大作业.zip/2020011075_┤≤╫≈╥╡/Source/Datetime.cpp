﻿/*************************************************************************
【文件名】                Datetime.cpp
【功能模块和目的】         Datetime类定义
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/

#include"Datetime.h"
#include<sstream>
#include<iomanip>

Date Datetime::d_Date = Date(1900,1,1) ;
Time Datetime::d_Time = Time(0,0,0);

/*************************************************************************
【函数名称】       Datetime
【函数功能】       构造函数
【参数】           Date& aDate, Time& aTime
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
Datetime::Datetime(Date& aDate, Time& aTime):date(mDate),time(mTime) {
	mDate = aDate;
    mTime = aTime;
}

/*************************************************************************
【函数名称】       operator<<
【函数功能】       输出运算符重载
【参数】           ostream& output, const Datetime& dt
【返回值】         ostream&
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
ostream& operator<<(ostream& output, const Datetime& dt) {
	output << dt.mDate << " " << dt.mTime << endl;
    return output;
}

/*************************************************************************
【函数名称】       operator>>
【函数功能】       输入运算符重载
【参数】          istream& input, Datetime& dt
【返回值】         istream&
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
istream& operator>>(istream& input, Datetime& dt){
    input >> dt.mDate >> dt.mTime;
    return input;
}

/*************************************************************************
【函数名称】       operator<
【函数功能】       小于号重载
【参数】          const Datetime& dt
【返回值】         bool
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
bool Datetime::operator<(const Datetime& dt) {
	if (mDate < dt.mDate) {
		return true;
	}
	else if (mDate == dt.mDate && mTime < dt.mTime) {
		return true;
	}
	else return false;

}

/*************************************************************************
【函数名称】       operator>
【函数功能】       大于号重载
【参数】           const Datetime& dt
【返回值】         bool
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
bool Datetime::operator>(const Datetime& dt) {
	if (mDate > dt.mDate) {
		return true;
	}
	else if (mDate == dt.mDate && mTime > dt.mTime) {
		return true;
	}
	else return false;

}

/*************************************************************************
【函数名称】       operator==
【函数功能】       比较判断符重载
【参数】          const Datetime& dt
【返回值】         bool
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
bool Datetime::operator==(const Datetime& dt) {
    if (mDate == dt.mDate && mTime == dt.mTime) {
		return true;
	}
	else return false;

}

/*************************************************************************
【函数名称】       operator=
【函数功能】       赋值运算符重载
【参数】          const Datetime& dt
【返回值】         Datetime&
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
Datetime& Datetime::operator=(const Datetime& dt) {
	if (this != &dt) {
		mDate = dt.date;
		mTime = dt.time;
	}
	return *this;
}

/*************************************************************************
【函数名称】       Tostring
【函数功能】       将Datetime成员转化为标准字符串格式
【参数】          const Datetime& dt
【返回值】         string
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
string Datetime::Tostring(const Datetime& dt){
    string formatYear = to_string(dt.date.Year)+"/"+to_string(dt.date.Month)+"/"+to_string(dt.date.Day);
    stringstream stream;
    stream<< setfill('0') << setw(2) << dt.time.Hour << ":"
         << setfill('0') << setw(2) << dt.time.Minute <<":"
         << setfill('0') << setw(2) << dt.time.Second;
    string formatTime = stream.str();
    string str = formatYear+" "+formatTime;
    return str;
}
