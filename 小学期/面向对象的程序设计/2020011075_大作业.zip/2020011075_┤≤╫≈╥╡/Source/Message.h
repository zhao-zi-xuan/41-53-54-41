﻿/*************************************************************************
【文件名】                message.h
【功能模块和目的】         message类声明
【开发者及日期】           PengCheng 2021.7.31
*************************************************************************/
#ifndef MESSAGE_H
#define MESSAGE_H
#include"Datetime.h"
#include<string>
#include<vector>
#include<iostream>
#include<memory>

//枚举类Type，表示message类型
enum class Type {
    WORD,
    ACTION,
    THOUGHT
};

/*************************************************************************
【类名】             Message
【功能】             存储，创建，查找Message
【接口说明】         Message(Datetime dt,Type tp, string content)
                   static void SortMessage()
                   void OutputToStream(ostream& Stream) const
                   static void LoadFromFile(const string& FileName)
                   static void SaveToFile(const string& FileName)
                   static Type FromString(const string& str)
                   static string ToString(const Type& tp)
                   static vector<shared_ptr<Message>>* SearchMessage(const Datetime& begin,const Datetime& end)
                   static void PublishMessage(const Datetime& dt,const Type& tp, const string& content)
                   friend ostream& operator<<(ostream& output, const Message& mg)
                   friend istream& operator>>(istream& input, Message& mg)
                   const Datetime& datetime
                   const string& content
                   const Type& type
【开发者及日期】     PengCheng 2021.8.7
*************************************************************************/
class Message {
public:
    Message(Datetime dt,Type tp, string content);//构造
    static void SortMessage();//按时间排序
    void OutputToStream(ostream& Stream) const;//输出到流
    static void LoadFromFile(const string& FileName);//从文件读取
    static void SaveToFile(const string& FileName);//保存到文件
    static Type FromString(const string& str);//将string转为Type类型
    static string ToString(const Type& tp);//Type类型转为string
    static vector<shared_ptr<Message>>* SearchMessage(const Datetime& begin,const Datetime& end);//搜索信息
    static void PublishMessage(const Datetime& dt,const Type& tp, const string& content);//发布信息
    friend ostream& operator<<(ostream& output, const Message& mg);//输出运算符重载
    friend istream& operator>>(istream& input, Message& mg);//输入运算符重载
    const Datetime& datetime;
    const string& content;
    const Type& type;
private:
    static vector<shared_ptr<Message>> m_AllMessage;//存储message的容器
    Datetime m_Datetime;
    string m_content;
    Type m_type;

};

#endif // MESSAGE_H








