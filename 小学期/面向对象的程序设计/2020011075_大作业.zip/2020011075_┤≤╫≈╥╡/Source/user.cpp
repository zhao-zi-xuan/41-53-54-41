﻿/*************************************************************************
【文件名】                user.cpp
【功能模块和目的】         用户类定义
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#include "user.h"
#include <string>
#include <vector>
#include <stdexcept>
#include <algorithm>
#include <memory>
#include <fstream>
using namespace std;
#include "administrator.h"

vector<shared_ptr<User>> User::m_All{};

/*************************************************************************
【函数名称】       User
【函数功能】       构造函数
【参数】          const string& Name, const CipherText& Password
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
User::User(const string& Name, const CipherText& Password) : m_Password(Password){
    auto Finder = [&Name](shared_ptr<User> ptr)->bool{return (ptr->m_Name == Name);};
    auto it = find_if(m_All.begin(), m_All.end(), Finder);
    if (it != m_All.end()) {
        if ((*it)->IsAdministrator()) {
            throw invalid_argument("Administrator exists.");
        }
        else {
            throw invalid_argument("Duplicate username");
        }
    }
    m_Name = Name;
    m_All.push_back(shared_ptr<User>(this));
}

/*************************************************************************
【函数名称】       AddUser
【函数功能】       添加用户
【参数】          const string& Name, const CipherText& Password
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void User::AddUser(const string& Name, const CipherText& Password){
    new User(Name, Password);
}

/*************************************************************************
【函数名称】       IsAdministrator
【函数功能】       虚函数，判断是否为管理员
【参数】          \
【返回值】         bool
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
bool User::IsAdministrator() const{
    return false;
}

/*************************************************************************
【函数名称】       OutputToStream
【函数功能】       输出到流
【参数】          ostream& Stream
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void User::OutputToStream(ostream& Stream) const{
    Stream << m_Name << endl << m_Password << endl;
}

/*************************************************************************
【函数名称】       SaveToFile
【函数功能】       将用户信息保存到文件
【参数】          const string& FileName
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void User::SaveToFile(const string& FileName){
    ofstream File(FileName);
    if (!File.is_open()) {
        throw invalid_argument("Can't Create File : " + FileName);
    }
    auto Saver = [&File](shared_ptr<User> Ptr){Ptr->OutputToStream(File);};
    File << m_All.size() << endl;
    for_each(m_All.begin(), m_All.end(),Saver);
    File.close();
}

/*************************************************************************
【函数名称】       LoadFromFile
【函数功能】       从文件读取用户信息
【参数】          const string& FileName
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void User::LoadFromFile(const string& FileName){
    ifstream File(FileName);
    if (!File.is_open()) {
        throw invalid_argument("File Not Exist: " + FileName);
    }
    unsigned long UserCount;
    File >> UserCount;
    File.get();
    if (UserCount <= 1) {
        new Administrator();
    }
    else{
        string Name;
        string Password;
        getline(File, Name);
        getline(File, Password);
        new Administrator(CipherText::MakeFromCipherText(Password));
        for (unsigned long i = 0; i < UserCount - 1; i++) {
            getline(File, Name);
            getline(File, Password);
            new User(Name, CipherText::MakeFromCipherText(Password));
        }
    }
   File.close();
}

/*************************************************************************
【函数名称】       Verify
【函数功能】       检验是否存在对应的用户名及密码
【参数】          const string& Name, const string& Password
【返回值】         shared_ptr<User>
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
shared_ptr<User> User::Verify(const string& Name, const string& Password){
    auto Finder = [&Name](shared_ptr<User> ptr)->bool{return (ptr->m_Name == Name);};
    auto it = find_if(m_All.begin(), m_All.end(), Finder);
    if (it == m_All.end()) {
        throw invalid_argument("No such user.");
    }
    else if ((*it)->m_Password != Password){
        throw invalid_argument("Wrong password.");
    }
    else {
        return *it;
    }
}
