﻿/*************************************************************************
【文件名】                 CipherText.h
【功能模块和目的】         加密字符串类函数声明
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/

#ifndef CipherText_hpp
#define CipherText_hpp
#include <string>
#include <ostream>
using namespace std;
#include "MD5.h"


/*************************************************************************
【类名】           CipherText
【功能】           MD5的子类密文类
【接口说明】        CipherText(const string& Plainext)
                  bool operator==(const string& Plaintext)
                  bool operator!=(const string& Plaintext)
                  CipherText operator= (const string& Plaintext)
                  friend ostream& operator<<(ostream& stream, const CipherText& CipherText)
                  static CipherText MakeFromCipherText(const string& CipherText)
【开发者及日期】     PengCheng 2021.8.7
*************************************************************************/
class CipherText : public MD5 {
public:
    CipherText(const string& Plainext);//构造函数
    bool operator==(const string& Plaintext);//比较运算符重载
    bool operator!=(const string& Plaintext);//不等号重载
    CipherText operator= (const string& Plaintext);//拷贝构造
    friend ostream& operator<<(ostream& stream, const CipherText& CipherText);//输出运算符重载
    static CipherText MakeFromCipherText(const string& CipherText);//将string型密文转为Ciphertext型密文
};

#endif /* CipherText_hpp */
