﻿/*************************************************************************
【文件名】                MessageWindow.h
【功能模块和目的】         MessageWindow类声明
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#ifndef MESSAGEWINDOW_H
#define MESSAGEWINDOW_H

#include <QMainWindow>
#include"Messagecontroler.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MessageWindow; }
QT_END_NAMESPACE

/*************************************************************************
【类名】             MessageWindow
【功能】             MessageWindow界面
【接口说明】          MessageWindow(QWidget *parent = nullptr)
                   ~MessageWindow()
【开发者及日期】     PengCheng 2021.8.7
*************************************************************************/
class MessageWindow : public QMainWindow
{
    Q_OBJECT

public:
    MessageWindow(QWidget *parent = nullptr);//构造
    ~MessageWindow();//析构

private slots:

    void on_PublishButton_clicked();//发布槽函数

    void on_SearchButton_clicked();//查找槽函数

    void on_ReturnButton_clicked();//返回槽函数

    void on_QuitButton_clicked();//退出槽函数

signals:
    void Reshowsignal();//返回上级界面

private:
    Ui::MessageWindow *ui;
    Messagecontroler Controler;
};
#endif // MessageWindow_H
