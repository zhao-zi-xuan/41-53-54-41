﻿/*************************************************************************
【文件名】                 logincontroler.cpp
【功能模块和目的】          定义类LoginControler
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#include "logincontroler.h"
#include "user.h"
#include "administrator.h"
#include "AdminDialog.h"

/*************************************************************************
【函数名称】       LoginControler
【函数功能】       构造函数，读取用户信息
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
LoginControler::LoginControler():userptr(m_userptr)
{
    User::LoadFromFile("Users.txt");
}


/*************************************************************************
【函数名称】       Login
【函数功能】       登录函数，接受用户名密码，返回登录结果
【参数】          const QString& Name, const QString& Password
【返回值】         LoginResult
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
LoginResult LoginControler::Login(const QString& Name, const QString& Password){
    try {
        shared_ptr<User> LoginedUser = User::Verify(Name.toStdString(), Password.toStdString());
        m_userptr = LoginedUser;
        if (LoginedUser->IsAdministrator()) {
            return LoginResult::ADMIN_LOGINED;
        }
        else {
            return LoginResult::USER_LOGINED;
        }
    } catch (invalid_argument e) {
        if (e.what() == string("No such user.")) {
            return LoginResult::NO_USER;
        }
        else {
            return LoginResult::WRONG_PASSWORD;
        }
    }
}
