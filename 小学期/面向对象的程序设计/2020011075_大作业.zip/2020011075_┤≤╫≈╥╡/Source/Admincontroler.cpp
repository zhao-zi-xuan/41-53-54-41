﻿/*************************************************************************
【文件名】                Admincontroler.cpp
【功能模块和目的】         Admincontrolerd的函数定义
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#include "Admincontroler.h"

/*************************************************************************
【函数名称】       Admincontroler()
【函数功能】       Admincontroler类的构造函数
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
Admincontroler::Admincontroler(){

}
Admincontroler::~Admincontroler(){
    User::SaveToFile("Users.txt");
}
/*************************************************************************
【函数名称】       Setuserptr
【函数功能】       设置m_userpr
【参数】          const shared_ptr<User>& userptr
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void Admincontroler::Setuserptr(const shared_ptr<User>& userptr){
    m_userptr = userptr;
}
/*************************************************************************
【函数名称】       AddNewUser
【函数功能】       添加新用户
【参数】          const QString &Name, const QString &Password
【返回值】         AdminResult
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
AdminResult Admincontroler::AddNewUser(const QString &Name, const QString &Password)
{
    try {
        Administrator* pAdmin = dynamic_cast<Administrator*>(m_userptr.get());
         pAdmin->AddUser(Name.toStdString(),Password.toStdString());
         User::SaveToFile("Users.txt");
         return AdminResult::NEWUSER_BUILT;
    } catch (invalid_argument e) {
        if(e.what()==string("Duplicate username")){
            return AdminResult::USERNAME_ALREADY_EXIST;
        }
        else if(e.what()==string("No Password")){
            return AdminResult::NULL_PASSWARD;
        }
        else if(e.what()==string("Administrator exists.")){
            return AdminResult::ADMIN_ALREADY_EXIST;
        }
        else{
             return AdminResult::NEWUSER_BUILT;
        }
    }

}
