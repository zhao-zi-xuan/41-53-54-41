﻿/*************************************************************************
【文件名】                Messagecontroler.h
【功能模块和目的】         Messagecontroler类声明
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#ifndef MESSAGECONTROLER_H
#define MESSAGECONTROLER_H
#include"Message.h"
#include<QString>
#include<QDateTime>

//发布结果
enum class PublishResult{
    Success,
    WrongDate,
    WrongTime,
    WrongType,
    WrongContent
};

//查找结果
enum class SearchResult{
    Success,
    InvalidDateTimeRange,
    NULLMessage
};

/*************************************************************************
【类名】             Messagecontroler
【功能】             控制底层message类与界面交互
【接口说明】         Messagecontroler();
                   SearchResult Messagesearch(const QDateTime& begin, const QDateTime& end);
                   PublishResult MessagePublish(QDateTime& dt,QString& tp, QString& content);
                   const vector<shared_ptr<Message>>& prtMessage;
                   static Datetime FromQDateTime(const QDateTime& qdatetime);
                   const int& word;
                   const int& action;
                   const int& thought;
                   ~Messagecontroler();
【开发者及日期】     PengCheng 2021.8.7
*************************************************************************/
class Messagecontroler
{
public:
    Messagecontroler();//构造，从文件读取message
    SearchResult Messagesearch(const QDateTime& begin, const QDateTime& end);//查找
    PublishResult MessagePublish(QDateTime& dt,QString& tp, QString& content);//发布
    const vector<shared_ptr<Message>>& prtMessage;
    static Datetime FromQDateTime(const QDateTime& qdatetime);//从QDatetime转为Datetime
    const int& word;
    const int& action;
    const int& thought;
    ~Messagecontroler();//析构，存储message到文件
private:
    vector<shared_ptr<Message>> m_prtMessage;//待输出的message的vector容器
    int m_word;//待输出的word数量
    int m_action;// 待输出的action数量
    int m_thought;//带输出的thought数量
};

#endif // MESSAGECONTROLER_H
