﻿/*************************************************************************
【文件名】                 MessageWindow.cpp
【功能模块和目的】         MessageWindow类定义
【开发者及日期】           PengCheng 2021.8.7
*************************************************************************/
#include "MessageWindow.h"
#include "ui_MessageWindow.h"
#include <QMessageBox>
#include"Messagecontroler.h"

/*************************************************************************
【函数名称】       MessageWindow
【函数功能】       构造函数
【参数】          QWidget *parent
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
MessageWindow::MessageWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MessageWindow)
{
    ui->setupUi(this);
    ui->PublishdateTimeEdit->setDisplayFormat("yyyy-MM-dd HH:mm:ss");
    ui->BegindateTimeEdit->setDisplayFormat("yyyy-MM-dd HH:mm:ss");
    ui->EnddateTimeEdit->setDisplayFormat("yyyy-MM-dd HH:mm:ss");
}

/*************************************************************************
【函数名称】       ~MessageWindow
【函数功能】       析构函数
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
MessageWindow::~MessageWindow()
{
    delete ui;
}

/*************************************************************************
【函数名称】       on_PublishButton_clicked
【函数功能】       发布按钮槽函数
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void MessageWindow::on_PublishButton_clicked()
{
    QDateTime datetime = ui->PublishdateTimeEdit->dateTime();
    QString qstr = ui->PublishtextEdit->toPlainText();
    QString type = ui->comboBox->currentText();

    PublishResult Res = Controler.MessagePublish(datetime, type, qstr);
    if (Res == PublishResult::WrongDate) {
        QMessageBox::information(NULL, "发布失败", "非法日期！", QMessageBox::Ok);
    }
    else if (Res == PublishResult::WrongTime) {
        QMessageBox::information(NULL, "发布失败", "非法时间！", QMessageBox::Ok);
    }
    else if (Res == PublishResult::WrongType) {
        QMessageBox::information(NULL, "发布失败", "非法类型！", QMessageBox::Ok);
    }
    else if(Res == PublishResult::WrongContent){
        QMessageBox::information(NULL, "发布失败", "内容不能为空", QMessageBox::Ok);
    }
    else{
        QMessageBox::information(NULL, "发布成功", "内容已保存", QMessageBox::Ok);
    }
    ui->PublishtextEdit->clear();
}

/*************************************************************************
【函数名称】       on_SearchButton_clicked
【函数功能】       查找按钮槽函数
【参数】          \
【返回值】         \
【开发者及日期】    pengcheng 2021.8.7
*************************************************************************/
void MessageWindow::on_SearchButton_clicked()
{
    ui->SearchtextBrowser->clear();
    QDateTime begindatetime = ui-> BegindateTimeEdit->dateTime();
    QDateTime enddatetime = ui-> EnddateTimeEdit->dateTime();
    SearchResult Res = Controler.Messagesearch(begindatetime,enddatetime);
    if (Res == SearchResult::InvalidDateTimeRange) {
        QMessageBox::information(NULL, "查询失败", "非法搜索区间！", QMessageBox::Ok);
    }
    else if (Res == SearchResult::NULLMessage) {
        QMessageBox::information(NULL, "发布失败", "当前区间内没有信息！", QMessageBox::Ok);
    }
    else{
        string wordcount = "Word:"+to_string(Controler.word);
        string actioncount = "Action:"+to_string(Controler.action);
        string thoughtcount = "Thought:"+to_string(Controler.thought);
        ui->SearchtextBrowser->append(QString::fromStdString(wordcount));
        ui->SearchtextBrowser->append(QString::fromStdString(actioncount));
        ui->SearchtextBrowser->append(QString::fromStdString(thoughtcount));


        auto printer = [&](shared_ptr<Message> M){
            ui->SearchtextBrowser->append(QString::fromStdString(Datetime::Tostring(M->datetime)));
            ui->SearchtextBrowser->append(QString::fromStdString(Message::ToString(M->type)));
            ui->SearchtextBrowser->append(QString::fromStdString(M->content));
        };
        for_each(Controler.prtMessage.begin(),Controler.prtMessage.end(),printer);
        QMessageBox::information(NULL, "查询成功", "已打印", QMessageBox::Ok);
    }

}
void MessageWindow::on_ReturnButton_clicked(){
    emit Reshowsignal();
    this->close();
    this->setAttribute(Qt::WA_DeleteOnClose,  true);

}

void MessageWindow::on_QuitButton_clicked(){
    this->close();
    this->setAttribute(Qt::WA_DeleteOnClose,  true);
}
